﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplaba5
{
    class Program
    {
        static void Main(string[] args)
        {
            Random r = new Random();
            List<int> dbset = new List<int>();
            for (int i = 0; i < 40; i++)
            {
                dbset.Add(r.Next(-25, 25));
            }
            var posNums = from n in dbset
                          orderby n
                          select n;
            Console.WriteLine("Значення за зростанням:");
            foreach (var i in posNums) Console.Write(i + " ");
            Console.ReadKey();

        }
    }
}